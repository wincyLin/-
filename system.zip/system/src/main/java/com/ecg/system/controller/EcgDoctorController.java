package com.ecg.system.controller;


import com.ecg.system.model.EcgDoctor;
import com.ecg.system.model.PageResult;
import com.ecg.system.model.Result;
import com.ecg.system.service.EcgDoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
public class EcgDoctorController {

    @Autowired
    private EcgDoctorService ecgDoctorService;

    @RequestMapping("/findAllDoctors")
    public List<EcgDoctor> findAllDoctors(){
        return ecgDoctorService.findAllDoctors();
    }

    @RequestMapping("/findOneDoctor/{docId}")
    public EcgDoctor findOneDoctor(@PathVariable int docId){
        return ecgDoctorService.findOneDoctor(docId);
    }

    @RequestMapping("/findByDoctorPage")
    public PageResult findByDoctorPage(Integer pageNo, Integer pageSize){
        return ecgDoctorService.findByDoctorPage(pageNo,pageSize);
    }

    @RequestMapping(value = "/addDoctors",method = RequestMethod.POST)
    public Result addDoctors(@RequestBody EcgDoctor doctors){
        try {
            ecgDoctorService.addDoctors(doctors);
            return new Result(true,"添加成功！");
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false,"添加失败！");
        }
    }

    @RequestMapping(value = "/updateDoctors",method = RequestMethod.POST)
    public Result updateDoctors(@RequestBody EcgDoctor doctors){
        System.out.println(doctors.getDocId());
        Result result = new Result();
        try {
            ecgDoctorService.updateDoctors(doctors);
            result.setSuccess(true);
        } catch (Exception e) {
            e.printStackTrace();
            result.setSuccess(false);
        }

        return result;
    }

    @RequestMapping("/deleteDoctors")
    public Result deleteDoctors(int[] docIds) {
        //System.out.println(ids[0]);

        Result result=new Result();
        try {
            ecgDoctorService.deleteDoctors(docIds);
            result.setSuccess(true);
        } catch (Exception e) {
            result.setSuccess(false);
            e.printStackTrace();
        }
        return result;
    }
//
//    @RequestMapping("/selectOptionList")
//    public List<Map> selectOptionList(){
//        return ecgUserService.selectOptionList();
//    }

    @RequestMapping("/findByDoctorName/{docName}")
   public EcgDoctor findByDoctorName(@PathVariable String docName){
        return ecgDoctorService.findByDoctorName(docName);
   }


}
