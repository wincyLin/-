package com.ecg.system.service;

import com.ecg.system.model.EcgInfo;
import com.ecg.system.model.EcgInfoExample;
import com.ecg.system.model.PageResult;

import java.util.List;

public interface EcgInfoService {


    long countByExample(EcgInfoExample example);

    int deleteByExample(EcgInfoExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(EcgInfo record);

    int insertSelective(EcgInfo record);

    List<EcgInfo> selectByExample(EcgInfoExample example);

    EcgInfo selectByPrimaryKey(Integer id);

    int updateByExampleSelective(EcgInfo record, EcgInfoExample example);

    int updateByExample(EcgInfo record, EcgInfoExample example);

    int updateByPrimaryKeySelective(EcgInfo record);

    int updateByPrimaryKey(EcgInfo record);

    List<EcgInfo> findByUserId(Integer userId);

    List<EcgInfo> findAllInfo();

    PageResult findByInfoPage(Integer pageNo, Integer pageSize);

    void addInfo(EcgInfo info);

    void updateInfo(EcgInfo info);

    EcgInfo findOneInfo(Integer id);

    void deleteInfo(Integer[] ids);

    PageResult searchInfo(EcgInfo info, Integer pageNum, Integer pageSize);


}




