package com.ecg.system.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
    * 心电图信息表
    */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EcgInfo {
    /**
    * 序号
    */
    private Integer id;

    /**
    * 图片
    */
    private String pic;

    /**
    * 备注
    */
    private String beizhu;

    private String createtime;

    private Integer userId;

    /**
    * 是否患者
    */
    private String huanzhe;

    /**
    * 健康状况
    */
    private String heathy;

    private String sex;

    private String age;
}