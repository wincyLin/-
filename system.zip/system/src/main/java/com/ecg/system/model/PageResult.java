package com.ecg.system.model;

import java.util.List;

public class PageResult {


    private List rows;//查询出来的区间集合


    public PageResult() {

    }

    public PageResult(long total, List rows) {
        // TODO Auto-generated constructor stub
        super();
        this.total = total;
        this.rows = rows;
    }


    public List getRows() {
        return rows;
    }

    public void setRows(List rows) {
        this.rows = rows;
    }

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    private Long total;//总记录数

}
