package com.ecg.system.mapper;

import com.ecg.system.model.EcgUser;
import com.ecg.system.model.EcgUserExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface EcgUserMapper {
    long countByExample(EcgUserExample example);

    int deleteByExample(EcgUserExample example);

    int deleteByPrimaryKey(Integer userId);

    int insert(EcgUser record);

    int insertSelective(EcgUser record);

    List<EcgUser> selectByExample(EcgUserExample example);

    EcgUser selectByPrimaryKey(Integer userId);

    int updateByExampleSelective(@Param("record") EcgUser record, @Param("example") EcgUserExample example);

    int updateByExample(@Param("record") EcgUser record, @Param("example") EcgUserExample example);

    int updateByPrimaryKeySelective(EcgUser record);

    int updateByPrimaryKey(EcgUser record);

    EcgUser selectByOne(String userName);
}