package com.ecg.system.service.impl;

import com.ecg.system.mapper.EcgUserMapper;
import com.ecg.system.model.EcgUser;
import com.ecg.system.model.EcgUserExample;
import com.ecg.system.model.PageResult;
import com.ecg.system.service.EcgUserService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EcgUserServiceImpl implements EcgUserService {


    @Autowired
    private EcgUserMapper ecgUserMapper;

    @Override
    public long countByExample(EcgUserExample example) {
        return ecgUserMapper.countByExample(example);
    }

    @Override
    public int deleteByExample(EcgUserExample example) {
        return ecgUserMapper.deleteByExample(example);
    }

    @Override
    public int deleteByPrimaryKey(Integer userId) {
        return ecgUserMapper.deleteByPrimaryKey(userId);
    }

    @Override
    public int insert(EcgUser record) {
        return ecgUserMapper.insert(record);
    }

    @Override
    public int insertSelective(EcgUser record) {
        return ecgUserMapper.insertSelective(record);
    }

    @Override
    public List<EcgUser> selectByExample(EcgUserExample example) {
        return ecgUserMapper.selectByExample(example);
    }

    @Override
    public EcgUser selectByPrimaryKey(Integer userId) {
        return ecgUserMapper.selectByPrimaryKey(userId);
    }

    @Override
    public int updateByExampleSelective(EcgUser record, EcgUserExample example) {
        return ecgUserMapper.updateByExampleSelective(record, example);
    }

    @Override
    public int updateByExample(EcgUser record, EcgUserExample example) {
        return ecgUserMapper.updateByExample(record, example);
    }

    @Override
    public int updateByPrimaryKeySelective(EcgUser record) {
        return ecgUserMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(EcgUser record) {
        return ecgUserMapper.updateByPrimaryKey(record);
    }

    @Override
    public List<EcgUser> findAllUsers() {
        List<EcgUser> list = ecgUserMapper.selectByExample(null);
        return list;
    }

    @Override
    public EcgUser findOneUser(int userId) {
        return ecgUserMapper.selectByPrimaryKey(userId);
    }

    @Override
    public PageResult findByUserPage(Integer pageNo, Integer pageSize) {
        PageResult pageResult = new PageResult();
        //分页第一步：设置mybatis的分页拦截，然后重构sql分页语句
        PageHelper.startPage(pageNo, pageSize);
        List<EcgUser> list = ecgUserMapper.selectByExample(null);

        //分页的第二步骤：获取分页bean，里面提供分页所需参数
        PageInfo pageInfo = new PageInfo<>(list);

        pageResult.setRows(list);
        pageResult.setTotal(pageInfo.getTotal());

        return pageResult;
    }

    @Override
    public void addUsers(EcgUser users) {
        ecgUserMapper.insert(users);
    }

    @Override
    public void updateUsers(EcgUser users) {
        ecgUserMapper.updateByPrimaryKey(users);
    }

    @Override
    public void deleteUsers(int[] userIds) {
        for (Integer userId : userIds) {
            ecgUserMapper.deleteByPrimaryKey(userId);
        }
    }

    @Override
    public EcgUser findByUserName(String userName) {
        return ecgUserMapper.selectByOne(userName);
    }

}
