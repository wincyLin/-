package com.ecg.system.service.impl;

import com.ecg.system.mapper.EcgInfoMapper;
import com.ecg.system.model.EcgInfo;
import com.ecg.system.model.EcgInfoExample;
import com.ecg.system.model.PageResult;
import com.ecg.system.model.Result;
import com.ecg.system.service.EcgInfoService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EcgInfoServiceImpl implements EcgInfoService{

    @Autowired
    private EcgInfoMapper ecgInfoMapper;



    @Override
    public long countByExample(EcgInfoExample example) {
        return ecgInfoMapper.countByExample(example);
    }

    @Override
    public int deleteByExample(EcgInfoExample example) {
        return ecgInfoMapper.deleteByExample(example);
    }

    @Override
    public int deleteByPrimaryKey(Integer id) {
        return ecgInfoMapper.deleteByPrimaryKey(id);
    }

    @Override
    public int insert(EcgInfo record) {
        return ecgInfoMapper.insert(record);
    }

    @Override
    public int insertSelective(EcgInfo record) {
        return ecgInfoMapper.insertSelective(record);
    }

    @Override
    public List<EcgInfo> selectByExample(EcgInfoExample example) {
        return ecgInfoMapper.selectByExample(example);
    }

    @Override
    public EcgInfo selectByPrimaryKey(Integer id) {
        return ecgInfoMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByExampleSelective(EcgInfo record,EcgInfoExample example) {
        return ecgInfoMapper.updateByExampleSelective(record,example);
    }

    @Override
    public int updateByExample(EcgInfo record,EcgInfoExample example) {
        return ecgInfoMapper.updateByExample(record,example);
    }

    @Override
    public int updateByPrimaryKeySelective(EcgInfo record) {
        return ecgInfoMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(EcgInfo record) {
        return ecgInfoMapper.updateByPrimaryKey(record);
    }

    @Override
    public List<EcgInfo> findByUserId(Integer userId) {
        return ecgInfoMapper.findByUserId(userId);
    }

    @Override
    public List<EcgInfo> findAllInfo() {
        return ecgInfoMapper.selectByExample(null);
    }

    @Override
    public PageResult findByInfoPage(Integer pageNo, Integer pageSize) {
        PageResult pageResult = new PageResult();
        //分页第一步：设置mybatis的分页拦截，然后重构sql分页语句
        PageHelper.startPage(pageNo, pageSize);
        List<EcgInfo> list = ecgInfoMapper.selectByExample(null);

        //分页的第二步骤：获取分页bean，里面提供分页所需参数
        PageInfo pageInfo = new PageInfo<>(list);

        pageResult.setRows(list);
        pageResult.setTotal(pageInfo.getTotal());

        return pageResult;

    }


    @Override
    public PageResult searchInfo(EcgInfo info,Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        EcgInfoExample example= new EcgInfoExample();
        EcgInfoExample.Criteria criteria = example.createCriteria();

        if(info!=null) {
            if(info.getPic()!=null && info.getPic().length()>0) {
                criteria.andPicLike("%"+info.getPic()+"%");
            }

        }
        Page<EcgInfo> page=   (Page<EcgInfo>) ecgInfoMapper.selectByExample(null);
        return new PageResult(page.getTotal(), page.getResult());
    }

    @Override
    public void addInfo(EcgInfo info) {
        ecgInfoMapper.insert(info);
//        redisTemplate.boundHashOps("Info").delete(info.getUserId());
    }

    @Override
    public void updateInfo(EcgInfo info) {
        //EcgInfo oldInfo= ecgInfoMapper.selectByPrimaryKey(info.getId());
//        redisTemplate.boundHashOps("Info").delete(oldInfo.getUserId());
        ecgInfoMapper.updateByPrimaryKey(info);
//        if(info.getUserId() !=oldInfo.getUserId()) {
//            redisTemplate.boundHashOps("Info").delete(info.getUserId());
//        }
    }

    @Override
    public EcgInfo findOneInfo(Integer id) {
        return ecgInfoMapper.selectByPrimaryKey(id);
    }

    @Override
    public void deleteInfo(Integer[] ids) {
        // TODO Auto-generated method stub
        Result result = null;
        try {
            for (int i=0;i<ids.length;i++){
                EcgInfo info = ecgInfoMapper.selectByPrimaryKey(ids[i]);
                //redisTemplate.boundHashOps("Info").delete(info.getUserId());
                ecgInfoMapper.deleteByPrimaryKey(ids[i]);
                result = new Result(true , "删除成功！");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result = new Result(false,"删除失败！");
        }

    }



}
