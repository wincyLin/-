package com.ecg.system.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 用户角色关联表
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserRole {
    /**
     * id
     */
    private Integer id;

    /**
     * 角色id
     */
    private Integer roleId;

    /**
     * 用户id
     */
    private Integer userId;

    public static UserRoleBuilder builder() {
        return new UserRoleBuilder();
    }
}