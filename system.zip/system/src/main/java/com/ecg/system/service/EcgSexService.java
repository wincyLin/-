package com.ecg.system.service;

import com.ecg.system.model.EcgSex;
import com.ecg.system.model.EcgSexExample;

import java.util.List;
public interface EcgSexService{


    long countByExample(EcgSexExample example);

    int deleteByExample(EcgSexExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(EcgSex record);

    int insertSelective(EcgSex record);

    List<EcgSex> selectByExample(EcgSexExample example);

    EcgSex selectByPrimaryKey(Integer id);

    int updateByExampleSelective(EcgSex record,EcgSexExample example);

    int updateByExample(EcgSex record,EcgSexExample example);

    int updateByPrimaryKeySelective(EcgSex record);

    int updateByPrimaryKey(EcgSex record);

    List<EcgSex> findAllSex();

    EcgSex findOneSex(int id);

    EcgSex findBySexName(String sexName);
}
