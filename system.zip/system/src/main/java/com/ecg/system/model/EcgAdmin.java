package com.ecg.system.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 管理员信息表
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EcgAdmin {
    /**
     * 序号
     */
    private Integer admId;

    /**
     * 管理员名
     */
    private String admName;

    private String password;

    public static EcgAdminBuilder builder() {
        return new EcgAdminBuilder();
    }
}