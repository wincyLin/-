package com.ecg.system.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 医生信息表
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EcgDoctor {
    /**
     * 序号
     */
    private Integer docId;

    /**
     * 医生名
     */
    private String docName;

    private String password;

    public static EcgDoctorBuilder builder() {
        return new EcgDoctorBuilder();
    }
}