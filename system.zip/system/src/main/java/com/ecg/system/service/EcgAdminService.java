package com.ecg.system.service;

import com.ecg.system.model.EcgAdmin;
import com.ecg.system.model.EcgAdminExample;
import com.ecg.system.model.PageResult;

import java.util.List;

public interface EcgAdminService {


    long countByExample(EcgAdminExample example);

    int deleteByExample(EcgAdminExample example);

    int deleteByPrimaryKey(Integer admId);

    int insert(EcgAdmin record);

    int insertSelective(EcgAdmin record);

    List<EcgAdmin> selectByExample(EcgAdminExample example);

    EcgAdmin selectByPrimaryKey(Integer admId);

    int updateByExampleSelective(EcgAdmin record, EcgAdminExample example);

    int updateByExample(EcgAdmin record, EcgAdminExample example);

    int updateByPrimaryKeySelective(EcgAdmin record);

    int updateByPrimaryKey(EcgAdmin record);

    List<EcgAdmin> findAllAdmins();

    EcgAdmin findOneAdmin(int admId);

    PageResult findByAdminPage(Integer pageNo, Integer pageSize);

    void addAdmins(EcgAdmin admins);

    void updateAdmins(EcgAdmin admins);

    void deleteAdmins(int[] admIds);

    EcgAdmin findByAdminName(String admName);
}

