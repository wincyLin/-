package com.ecg.system.service.impl;

import com.ecg.system.mapper.EcgHuanMapper;
import com.ecg.system.model.EcgHuan;
import com.ecg.system.model.EcgHuanExample;
import com.ecg.system.service.EcgHuanService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service
public class EcgHuanServiceImpl implements EcgHuanService{

    @Resource
    private EcgHuanMapper ecgHuanMapper;

    @Override
    public long countByExample(EcgHuanExample example) {
        return ecgHuanMapper.countByExample(example);
    }

    @Override
    public int deleteByExample(EcgHuanExample example) {
        return ecgHuanMapper.deleteByExample(example);
    }

    @Override
    public int deleteByPrimaryKey(Integer id) {
        return ecgHuanMapper.deleteByPrimaryKey(id);
    }

    @Override
    public int insert(EcgHuan record) {
        return ecgHuanMapper.insert(record);
    }

    @Override
    public int insertSelective(EcgHuan record) {
        return ecgHuanMapper.insertSelective(record);
    }

    @Override
    public List<EcgHuan> selectByExample(EcgHuanExample example) {
        return ecgHuanMapper.selectByExample(example);
    }

    @Override
    public EcgHuan selectByPrimaryKey(Integer id) {
        return ecgHuanMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByExampleSelective(EcgHuan record,EcgHuanExample example) {
        return ecgHuanMapper.updateByExampleSelective(record,example);
    }

    @Override
    public int updateByExample(EcgHuan record,EcgHuanExample example) {
        return ecgHuanMapper.updateByExample(record,example);
    }

    @Override
    public int updateByPrimaryKeySelective(EcgHuan record) {
        return ecgHuanMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(EcgHuan record) {
        return ecgHuanMapper.updateByPrimaryKey(record);
    }

    @Override
    public EcgHuan findOneHuan(int id) {
        return ecgHuanMapper.selectByPrimaryKey(id);
    }

    @Override
    public EcgHuan findByHuanName(String huanName) {
        return ecgHuanMapper.findByHuanName(huanName);
    }

    @Override
    public List<EcgHuan> findAllHuan() {
        List<EcgHuan> list = ecgHuanMapper.selectByExample(null);
        return list;
    }

}
