package com.ecg.system.service.impl;

import com.ecg.system.mapper.EcgDoctorMapper;
import com.ecg.system.model.EcgDoctor;
import com.ecg.system.model.EcgDoctorExample;
import com.ecg.system.model.PageResult;
import com.ecg.system.service.EcgDoctorService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EcgDoctorServiceImpl implements EcgDoctorService{

    @Autowired
    private EcgDoctorMapper ecgDoctorMapper;

    @Override
    public long countByExample(EcgDoctorExample example) {
        return ecgDoctorMapper.countByExample(example);
    }

    @Override
    public int deleteByExample(EcgDoctorExample example) {
        return ecgDoctorMapper.deleteByExample(example);
    }

    @Override
    public int deleteByPrimaryKey(Integer docId) {
        return ecgDoctorMapper.deleteByPrimaryKey(docId);
    }

    @Override
    public int insert(EcgDoctor record) {
        return ecgDoctorMapper.insert(record);
    }

    @Override
    public int insertSelective(EcgDoctor record) {
        return ecgDoctorMapper.insertSelective(record);
    }

    @Override
    public List<EcgDoctor> selectByExample(EcgDoctorExample example) {
        return ecgDoctorMapper.selectByExample(example);
    }

    @Override
    public EcgDoctor selectByPrimaryKey(Integer docId) {
        return ecgDoctorMapper.selectByPrimaryKey(docId);
    }

    @Override
    public int updateByExampleSelective(EcgDoctor record,EcgDoctorExample example) {
        return ecgDoctorMapper.updateByExampleSelective(record,example);
    }

    @Override
    public int updateByExample(EcgDoctor record,EcgDoctorExample example) {
        return ecgDoctorMapper.updateByExample(record,example);
    }

    @Override
    public int updateByPrimaryKeySelective(EcgDoctor record) {
        return ecgDoctorMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(EcgDoctor record) {
        return ecgDoctorMapper.updateByPrimaryKey(record);
    }

    @Override
    public List<EcgDoctor> findAllDoctors() {
        List<EcgDoctor>list= ecgDoctorMapper.selectByExample(null);
        return list;
    }

    @Override
    public EcgDoctor findOneDoctor(int docId) {
        return ecgDoctorMapper.selectByPrimaryKey(docId);
    }

    @Override
    public PageResult findByDoctorPage(Integer pageNo, Integer pageSize) {
        PageResult pageResult=new PageResult();
        //分页第一步：设置mybatis的分页拦截，然后重构sql分页语句
        PageHelper.startPage(pageNo, pageSize);
        List<EcgDoctor>list=ecgDoctorMapper.selectByExample(null);

        //分页的第二步骤：获取分页bean，里面提供分页所需参数
        PageInfo pageInfo=new PageInfo<>(list);

        pageResult.setRows(list);
        pageResult.setTotal(pageInfo.getTotal());

        return pageResult;
    }

    @Override
    public void deleteDoctors(int[] docIds) {
        for (Integer docId : docIds) {
            ecgDoctorMapper.deleteByPrimaryKey(docId);
        }
    }

    @Override
    public EcgDoctor findByDoctorName(String docName) {
        return ecgDoctorMapper.selectByOne(docName);
    }

    @Override
    public void updateDoctors(EcgDoctor doctors) {
        ecgDoctorMapper.updateByPrimaryKey(doctors);
    }

    @Override
    public void addDoctors(EcgDoctor doctors) {
        ecgDoctorMapper.insert(doctors);
    }

}
