package com.ecg.system.mapper;

import com.ecg.system.model.EcgHuan;
import com.ecg.system.model.EcgHuanExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface EcgHuanMapper {
    long countByExample(EcgHuanExample example);

    int deleteByExample(EcgHuanExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(EcgHuan record);

    int insertSelective(EcgHuan record);

    List<EcgHuan> selectByExample(EcgHuanExample example);

    EcgHuan selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") EcgHuan record, @Param("example") EcgHuanExample example);

    int updateByExample(@Param("record") EcgHuan record, @Param("example") EcgHuanExample example);

    int updateByPrimaryKeySelective(EcgHuan record);

    int updateByPrimaryKey(EcgHuan record);

    EcgHuan findByHuanName(String huanName);
}