package com.ecg.system.controller;


import com.ecg.system.model.EcgHuan;
import com.ecg.system.service.EcgHuanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
public class EcgHuanController {
    @Autowired
    private EcgHuanService ecgHuanService;

    @RequestMapping("/findAllHuan")
    public List<EcgHuan> findAllHuan(){
        return ecgHuanService.findAllHuan();
    }

    @RequestMapping("/findOneHuan/{id}")
    public EcgHuan findOneHuan(@PathVariable int id){
        return ecgHuanService.findOneHuan(id);
    }

    @RequestMapping("/findByHuanName/{huanName}")
    public EcgHuan findByHuanName(@PathVariable String huanName){
        return ecgHuanService.findByHuanName(huanName);
    }

}
