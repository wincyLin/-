package com.ecg.system.mapper;

import com.ecg.system.model.EcgInfo;
import com.ecg.system.model.EcgInfoExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface EcgInfoMapper {
    long countByExample(EcgInfoExample example);

    int deleteByExample(EcgInfoExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(EcgInfo record);

    int insertSelective(EcgInfo record);

    List<EcgInfo> selectByExample(EcgInfoExample example);

    EcgInfo selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") EcgInfo record, @Param("example") EcgInfoExample example);

    int updateByExample(@Param("record") EcgInfo record, @Param("example") EcgInfoExample example);

    int updateByPrimaryKeySelective(EcgInfo record);

    int updateByPrimaryKey(EcgInfo record);

    List<EcgInfo> findByUserId(Integer userId);
}