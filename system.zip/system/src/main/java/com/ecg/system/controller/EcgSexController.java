package com.ecg.system.controller;

import com.ecg.system.model.EcgSex;
import com.ecg.system.service.EcgSexService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
public class EcgSexController {

    @Autowired
    private EcgSexService ecgSexService;

    @RequestMapping("/findAllSex")
    public List<EcgSex> findAllSex(){
        return ecgSexService.findAllSex();
    }

    @RequestMapping("/findOneSex/{id}")
    public EcgSex findOneSex(@PathVariable int id){
        return ecgSexService.findOneSex(id);
    }

    @RequestMapping("/findBySexName/{sexName}")
    public EcgSex findBySexName(@PathVariable String sexName){
        return ecgSexService.findBySexName(sexName);
    }


}




