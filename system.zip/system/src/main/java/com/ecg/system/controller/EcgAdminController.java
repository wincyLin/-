package com.ecg.system.controller;


import com.ecg.system.model.EcgAdmin;
import com.ecg.system.model.PageResult;
import com.ecg.system.model.Result;
import com.ecg.system.service.EcgAdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
public class EcgAdminController {

    @Autowired
    private EcgAdminService ecgAdminService;

    @RequestMapping("/findAllAdmins")
    public List<EcgAdmin> findAllAdmins(){
        return ecgAdminService.findAllAdmins();
    }

    @RequestMapping("/findOneAdmin/{admId}")
    public EcgAdmin findOneAdmin(@PathVariable int admId){
        return ecgAdminService.findOneAdmin(admId);
    }

    @RequestMapping("/findByAdminPage")
    public PageResult findByAdminPage(Integer pageNo, Integer pageSize){
        return ecgAdminService.findByAdminPage(pageNo,pageSize);
    }

    @RequestMapping(value = "/addAdmins",method = RequestMethod.POST)
    public Result addAdmins(@RequestBody EcgAdmin admins){
        try {
            ecgAdminService.addAdmins(admins);
            return new Result(true,"添加成功！");
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false,"添加失败！");
        }
    }

    @RequestMapping(value = "/updateAdmins",method = RequestMethod.POST)
    public Result updateAdmins(@RequestBody EcgAdmin admins){
        System.out.println(admins.getAdmId());
        Result result = new Result();
        try {
            ecgAdminService.updateAdmins(admins);
            result.setSuccess(true);
        } catch (Exception e) {
            e.printStackTrace();
            result.setSuccess(false);
        }

        return result;
    }

    @RequestMapping("/deleteAdmins")
    public Result deleteAdmins(int[] admIds) {
        //System.out.println(ids[0]);

        Result result=new Result();
        try {
            ecgAdminService.deleteAdmins(admIds);
            result.setSuccess(true);
        } catch (Exception e) {
            result.setSuccess(false);
            e.printStackTrace();
        }
        return result;
    }
//
//    @RequestMapping("/selectOptionList")
//    public List<Map> selectOptionList(){
//        return ecgUserService.selectOptionList();
//    }

    @RequestMapping(value="/findByAdminName/{admName}" ,method = RequestMethod.GET)
   public EcgAdmin findByAdminName(@PathVariable String admName){
        return ecgAdminService.findByAdminName(admName);
   }


}
