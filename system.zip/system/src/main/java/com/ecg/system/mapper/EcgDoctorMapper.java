package com.ecg.system.mapper;

import com.ecg.system.model.EcgDoctor;
import com.ecg.system.model.EcgDoctorExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface EcgDoctorMapper {
    long countByExample(EcgDoctorExample example);

    int deleteByExample(EcgDoctorExample example);

    int deleteByPrimaryKey(Integer docId);

    int insert(EcgDoctor record);

    int insertSelective(EcgDoctor record);

    List<EcgDoctor> selectByExample(EcgDoctorExample example);

    EcgDoctor selectByPrimaryKey(Integer docId);

    int updateByExampleSelective(@Param("record") EcgDoctor record, @Param("example") EcgDoctorExample example);

    int updateByExample(@Param("record") EcgDoctor record, @Param("example") EcgDoctorExample example);

    int updateByPrimaryKeySelective(EcgDoctor record);

    int updateByPrimaryKey(EcgDoctor record);

    EcgDoctor selectByOne(String docName);
}