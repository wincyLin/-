package com.ecg.system.service.impl;

import com.ecg.system.mapper.EcgSexMapper;
import com.ecg.system.model.EcgSex;
import com.ecg.system.model.EcgSexExample;
import com.ecg.system.service.EcgSexService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service
public class EcgSexServiceImpl implements EcgSexService{

    @Resource
    private EcgSexMapper ecgSexMapper;

    @Override
    public long countByExample(EcgSexExample example) {
        return ecgSexMapper.countByExample(example);
    }

    @Override
    public int deleteByExample(EcgSexExample example) {
        return ecgSexMapper.deleteByExample(example);
    }

    @Override
    public int deleteByPrimaryKey(Integer id) {
        return ecgSexMapper.deleteByPrimaryKey(id);
    }

    @Override
    public int insert(EcgSex record) {
        return ecgSexMapper.insert(record);
    }

    @Override
    public int insertSelective(EcgSex record) {
        return ecgSexMapper.insertSelective(record);
    }

    @Override
    public List<EcgSex> selectByExample(EcgSexExample example) {
        return ecgSexMapper.selectByExample(example);
    }

    @Override
    public EcgSex selectByPrimaryKey(Integer id) {
        return ecgSexMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByExampleSelective(EcgSex record,EcgSexExample example) {
        return ecgSexMapper.updateByExampleSelective(record,example);
    }

    @Override
    public int updateByExample(EcgSex record,EcgSexExample example) {
        return ecgSexMapper.updateByExample(record,example);
    }

    @Override
    public int updateByPrimaryKeySelective(EcgSex record) {
        return ecgSexMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(EcgSex record) {
        return ecgSexMapper.updateByPrimaryKey(record);
    }

    @Override
    public List<EcgSex> findAllSex() {
        List<EcgSex> list = ecgSexMapper.selectByExample(null);
        return list;
    }

    @Override
    public EcgSex findOneSex(int id) {
        return ecgSexMapper.selectByPrimaryKey(id);
    }

    @Override
    public EcgSex findBySexName(String sexName) {
        return ecgSexMapper.findBySexName(sexName);
    }

}
