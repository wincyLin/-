package com.ecg.system.mapper;

import com.ecg.system.model.EcgSex;
import com.ecg.system.model.EcgSexExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface EcgSexMapper {
    long countByExample(EcgSexExample example);

    int deleteByExample(EcgSexExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(EcgSex record);

    int insertSelective(EcgSex record);

    List<EcgSex> selectByExample(EcgSexExample example);

    EcgSex selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") EcgSex record, @Param("example") EcgSexExample example);

    int updateByExample(@Param("record") EcgSex record, @Param("example") EcgSexExample example);

    int updateByPrimaryKeySelective(EcgSex record);

    int updateByPrimaryKey(EcgSex record);

    EcgSex findBySexName(String sexName);
}