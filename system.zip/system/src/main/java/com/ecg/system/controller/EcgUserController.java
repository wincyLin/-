package com.ecg.system.controller;


import com.ecg.system.model.EcgUser;
import com.ecg.system.model.PageResult;
import com.ecg.system.model.Result;
import com.ecg.system.service.EcgUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
public class EcgUserController {

    @Autowired
    private EcgUserService ecgUserService;

    @RequestMapping("/findAllUsers")
    public List<EcgUser> findAllUsers(){
        return ecgUserService.findAllUsers();
    }

    @RequestMapping("/findOneUser/{userId}")
    public EcgUser findOneUser(@PathVariable int userId){
        return ecgUserService.findOneUser(userId);
    }

    @RequestMapping("/findByUserPage")
    public PageResult findByUserPage(Integer pageNo, Integer pageSize){
        return ecgUserService.findByUserPage(pageNo,pageSize);
    }

    @RequestMapping(value = "/addUsers",method = RequestMethod.POST)
    public Result addUsers(@RequestBody EcgUser users){
        try {
            ecgUserService.addUsers(users);
            return new Result(true,"添加成功！");
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false,"添加失败！");
        }
    }

    @RequestMapping(value = "/updateUsers",method = RequestMethod.POST)
    public Result updateUsers(@RequestBody EcgUser users){
        System.out.println(users.getUserId());
        Result result = new Result();
        try {
            ecgUserService.updateUsers(users);
            result.setSuccess(true);
        } catch (Exception e) {
            e.printStackTrace();
            result.setSuccess(false);
        }

        return result;
    }

    @RequestMapping("/deleteUsers")
    public Result deleteUsers(int[] userIds) {
        //System.out.println(ids[0]);

        Result result=new Result();
        try {
            ecgUserService.deleteUsers(userIds);
            result.setSuccess(true);
        } catch (Exception e) {
            result.setSuccess(false);
            e.printStackTrace();
        }
        return result;
    }
//
//    @RequestMapping("/selectOptionList")
//    public List<Map> selectOptionList(){
//        return ecgUserService.selectOptionList();
//    }

    @RequestMapping("/findByUserName/{userName}")
   public EcgUser findByUserName(@PathVariable String userName){
        return ecgUserService.findByUserName(userName);
   }


}
