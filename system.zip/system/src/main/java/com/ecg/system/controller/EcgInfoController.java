package com.ecg.system.controller;


import com.ecg.system.model.EcgInfo;
import com.ecg.system.model.PageResult;
import com.ecg.system.model.Result;
import com.ecg.system.service.EcgInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
public class EcgInfoController {

    @Autowired
    private EcgInfoService ecgInfoService;

    @RequestMapping("/findByUserId/{userId}")
    public List<EcgInfo> findByUserId(@PathVariable Integer userId){
        return ecgInfoService.findByUserId(userId);
    }

    @RequestMapping("/findAllInfo")
    public List<EcgInfo> findAllEcgInfo(){
        return ecgInfoService.findAllInfo();
    }

    @RequestMapping("/findByInfoPage")
    public PageResult findByInfoPage(Integer pageNo, Integer pageSize){
        return ecgInfoService.findByInfoPage(pageNo, pageSize);
    }

    @RequestMapping(value="/addInfo",method = RequestMethod.POST)
    public Result addInfo(@RequestBody EcgInfo info){
        System.out.println(info.getUserId());
        System.out.println(info.getPic());
        System.out.println(info.getHeathy());
        System.out.println(info.getSex());

        try {
            ecgInfoService.addInfo(info);
            return new Result(true, "增加成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, "增加失败");
        }
    }

    @RequestMapping(value="/updateInfo",method = RequestMethod.POST)
    public Result updateInfo(@RequestBody EcgInfo info){
        System.out.println(info.getUserId());
        System.out.println(info.getId());
        System.out.println(info.getPic());
        System.out.println(info.getHeathy());
        System.out.println(info.getPic());

        try {
            ecgInfoService.updateInfo(info);
            return new Result(true, "修改成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, "修改失败");
        }
    }

    @RequestMapping("/findOneInfo/{id}")
    public EcgInfo findOneInfo(@PathVariable Integer id){
        return ecgInfoService.findOneInfo(id);
    }


    @RequestMapping(value="/deleteInfo",method = RequestMethod.GET)
    public Result deleteInfo(Integer [] ids){

        Result result=new Result();
        try {
            ecgInfoService.deleteInfo(ids);
            result.setSuccess(true);
        } catch (Exception e) {
            result.setSuccess(false);
            e.printStackTrace();
        }
        return result;

    }

    @RequestMapping("/searchInfo")
    public PageResult searchInfo(@RequestBody EcgInfo info, Integer pageNum, Integer pageSize){
        return ecgInfoService.searchInfo(info, pageNum, pageSize);
    }





}
