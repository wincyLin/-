package com.ecg.system.mapper;

import com.ecg.system.model.EcgAdmin;
import com.ecg.system.model.EcgAdminExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface EcgAdminMapper {
    long countByExample(EcgAdminExample example);

    int deleteByExample(EcgAdminExample example);

    int deleteByPrimaryKey(Integer admId);

    int insert(EcgAdmin record);

    int insertSelective(EcgAdmin record);

    List<EcgAdmin> selectByExample(EcgAdminExample example);

    EcgAdmin selectByPrimaryKey(Integer admId);

    int updateByExampleSelective(@Param("record") EcgAdmin record, @Param("example") EcgAdminExample example);

    int updateByExample(@Param("record") EcgAdmin record, @Param("example") EcgAdminExample example);

    int updateByPrimaryKeySelective(EcgAdmin record);

    int updateByPrimaryKey(EcgAdmin record);

    EcgAdmin selectByOne(String admName);
}