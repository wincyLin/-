package com.ecg.system.service;

import com.ecg.system.model.*;

import java.util.List;

public interface EcgDoctorService {


    long countByExample(EcgDoctorExample example);

    int deleteByExample(EcgDoctorExample example);

    int deleteByPrimaryKey(Integer docId);

    int insert(EcgDoctor record);

    int insertSelective(EcgDoctor record);

    List<EcgDoctor> selectByExample(EcgDoctorExample example);

    EcgDoctor selectByPrimaryKey(Integer docId);

    int updateByExampleSelective(EcgDoctor record, EcgDoctorExample example);

    int updateByExample(EcgDoctor record, EcgDoctorExample example);

    int updateByPrimaryKeySelective(EcgDoctor record);

    int updateByPrimaryKey(EcgDoctor record);


    List<EcgDoctor> findAllDoctors();

    EcgDoctor findOneDoctor(int docId);

    PageResult findByDoctorPage(Integer pageNo, Integer pageSize);

    void deleteDoctors(int[] docIds);

    EcgDoctor findByDoctorName(String docName);

    void updateDoctors(EcgDoctor doctors);

    void addDoctors(EcgDoctor doctors);
}

