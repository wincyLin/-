package com.ecg.system.service;

import com.ecg.system.model.EcgHuan;
import com.ecg.system.model.EcgHuanExample;

import java.util.List;
public interface EcgHuanService{


    long countByExample(EcgHuanExample example);

    int deleteByExample(EcgHuanExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(EcgHuan record);

    int insertSelective(EcgHuan record);

    List<EcgHuan> selectByExample(EcgHuanExample example);

    EcgHuan selectByPrimaryKey(Integer id);

    int updateByExampleSelective(EcgHuan record,EcgHuanExample example);

    int updateByExample(EcgHuan record,EcgHuanExample example);

    int updateByPrimaryKeySelective(EcgHuan record);

    int updateByPrimaryKey(EcgHuan record);

    EcgHuan findOneHuan(int id);

    EcgHuan findByHuanName(String huanName);

    List<EcgHuan> findAllHuan();
}
