package com.ecg.system.service;

import com.ecg.system.model.EcgUser;
import com.ecg.system.model.EcgUserExample;
import com.ecg.system.model.PageResult;

import java.util.List;


public interface EcgUserService {


    long countByExample(EcgUserExample example);

    int deleteByExample(EcgUserExample example);

    int deleteByPrimaryKey(Integer userId);

    int insert(EcgUser record);

    int insertSelective(EcgUser record);

    List<EcgUser> selectByExample(EcgUserExample example);

    EcgUser selectByPrimaryKey(Integer userId);

    int updateByExampleSelective(EcgUser record, EcgUserExample example);

    int updateByExample(EcgUser record, EcgUserExample example);

    int updateByPrimaryKeySelective(EcgUser record);

    int updateByPrimaryKey(EcgUser record);

    List<EcgUser> findAllUsers();

    EcgUser findOneUser(int userId);

    PageResult findByUserPage(Integer pageNo, Integer pageSize);

    void addUsers(EcgUser users);

    void updateUsers(EcgUser users);

    void deleteUsers(int[] userIds);

    EcgUser findByUserName(String userName);

//    EcgUser SelectForLogin(String userName, String password);
}


