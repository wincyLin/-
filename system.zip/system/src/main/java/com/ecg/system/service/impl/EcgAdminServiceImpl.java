package com.ecg.system.service.impl;

import com.ecg.system.mapper.EcgAdminMapper;
import com.ecg.system.model.EcgAdmin;
import com.ecg.system.model.EcgAdminExample;
import com.ecg.system.model.PageResult;
import com.ecg.system.service.EcgAdminService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EcgAdminServiceImpl implements EcgAdminService{

    @Autowired
    private EcgAdminMapper ecgAdminMapper;

    @Override
    public long countByExample(EcgAdminExample example) {
        return ecgAdminMapper.countByExample(example);
    }

    @Override
    public int deleteByExample(EcgAdminExample example) {
        return ecgAdminMapper.deleteByExample(example);
    }

    @Override
    public int deleteByPrimaryKey(Integer admId) {
        return ecgAdminMapper.deleteByPrimaryKey(admId);
    }

    @Override
    public int insert(EcgAdmin record) {
        return ecgAdminMapper.insert(record);
    }

    @Override
    public int insertSelective(EcgAdmin record) {
        return ecgAdminMapper.insertSelective(record);
    }

    @Override
    public List<EcgAdmin> selectByExample(EcgAdminExample example) {
        return ecgAdminMapper.selectByExample(example);
    }

    @Override
    public EcgAdmin selectByPrimaryKey(Integer admId) {
        return ecgAdminMapper.selectByPrimaryKey(admId);
    }

    @Override
    public int updateByExampleSelective(EcgAdmin record,EcgAdminExample example) {
        return ecgAdminMapper.updateByExampleSelective(record,example);
    }

    @Override
    public int updateByExample(EcgAdmin record,EcgAdminExample example) {
        return ecgAdminMapper.updateByExample(record,example);
    }

    @Override
    public int updateByPrimaryKeySelective(EcgAdmin record) {
        return ecgAdminMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(EcgAdmin record) {
        return ecgAdminMapper.updateByPrimaryKey(record);
    }

    @Override
    public List<EcgAdmin> findAllAdmins() {
        List<EcgAdmin>list= ecgAdminMapper.selectByExample(null);
        return list;
    }

    @Override
    public EcgAdmin findOneAdmin(int admId) {
        return ecgAdminMapper.selectByPrimaryKey(admId);
    }

    @Override
    public PageResult findByAdminPage(Integer pageNo, Integer pageSize) {
        PageResult pageResult=new PageResult();
        //分页第一步：设置mybatis的分页拦截，然后重构sql分页语句
        PageHelper.startPage(pageNo, pageSize);
        List<EcgAdmin>list=ecgAdminMapper.selectByExample(null);

        //分页的第二步骤：获取分页bean，里面提供分页所需参数
        PageInfo pageInfo=new PageInfo<>(list);

        pageResult.setRows(list);
        pageResult.setTotal(pageInfo.getTotal());

        return pageResult;
    }

    @Override
    public void addAdmins(EcgAdmin admins) {
        ecgAdminMapper.insert(admins);
    }

    @Override
    public void updateAdmins(EcgAdmin admins) {
        ecgAdminMapper.updateByPrimaryKey(admins);
    }

    @Override
    public void deleteAdmins(int[] admIds) {
        for (Integer admId : admIds) {
            ecgAdminMapper.deleteByPrimaryKey(admId);
        }
    }

    @Override
    public EcgAdmin findByAdminName(String admName) {
        return ecgAdminMapper.selectByOne(admName);
    }

}
